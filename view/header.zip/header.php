<!DOCTYPE html>
<html>
<head>
<title>Cancer Curation Viewer</title>
<link href="<?php echo CSS_PATH; ?>/login.css" rel="stylesheet" type="text/css">
 
 
 
	<link rel="stylesheet" type="text/css" href="<?php echo CSS_PATH; ?>/jquery.dataTables.css">
	
	<script src="<?php echo JS_PATH;?>/jquery.js" type="text/javascript" language="javascript" ></script>
	<script src="<?php echo JS_PATH;?>/jquery.dataTables.js" type="text/javascript" language="javascript" ></script>
	
</head>
<body>
<?php echo JS_PATH;?>
<?php echo CSS_PATH; ?>
<div>
   <h3 style="color: #594F4F; font-family: 'Droid serif', serif; font-size: 36px; font-weight: 400; font-style: italic; line-height: 44px; margin: 0 0 12px; text-align: center; ">
      Variant Curation Viewer
   </h3>
</div>
<script>
var gtissue;
var ggene;
var gmutation;
$(document).ready(function(){
   addList();
   $("#tumorTypeselect").change(function() {
		var tissue=$("#tumorTypeselect option:selected").val();
		addcellList(tissue);
   });
   $("#geneselect").change(function() {
		var genename=$("#geneselect option:selected").val();
		var tissue=$("#tumorTypeselect option:selected").val();
		addMutationList(tissue,genename);
			
	});
});
function narrative(e,tumor,gene,mutation){
	e.preventDefault();
	gtissue=tumor;
    ggene=gene;
    gmutation=mutation;
	
	
	getnarrative("tissue");
	
	
}
function getnarrative(tissue){
		$.ajax({
			type : 'POST',
			url : 'getnarrative',
			dataType : 'text',
			data: {
				
				cancer:tissue
				
			},
			success : function(data1){
				//alert(data1);
				$("#nardiv").html(data1);
				return false;
			  
			},
			 error : function(XMLHttpRequest, textStatus, errorThrown) {
				 alert("Parse error");
				
			 }
		});
}
function addcellList(tissue){
		$.ajax({
			type : 'POST',
			url : 'getgenes',
			dataType : 'text',
			data: {
				
				cancer:tissue
				
			},
			success : function(data1){
			  var celllineList=data1.split("\n");
			  $("#geneselect").empty();
				var ddl = $("#geneselect"); 
				ddl.append("<option value='3'>Please select gene</option>");				
				for (k = 0; k < celllineList.length; k++)
					ddl.append("<option value='" + celllineList[k]+ "'>" + celllineList[k] + "</option>");
					return false;
				},
			 error : function(XMLHttpRequest, textStatus, errorThrown) {
				 alert("Parse error");
				
			 }
		});
}

function addMutationList(tissue,gene){
		$.ajax({
			type : 'POST',
			url : 'getgenemutations',
			dataType : 'text',
			data: {
				cancer:tissue,
				gene:gene
			},
			success : function(data1){
			  var celllineList=data1.split("\n");
			  $("#mutationselect").empty();
			  var ddl = $("#mutationselect"); 
			  ddl.append("<option value='1'>Please select mutation</option>");				
			  for (k = 0; k < celllineList.length; k++)
					ddl.append("<option value='" + celllineList[k]+ "'>" + celllineList[k] + "</option>");
					return false;
				
			
				},
			 error : function(XMLHttpRequest, textStatus, errorThrown) {
				//$('#waiting').hide(500);
				alert("Parse error");
				
			}
		});
		
}



function addList(){
	$.ajax({
		//asyn:false,
		type : 'POST',
		url : 'gettumor',
		dataType : 'text',
		success : function(data1){
			alert("vadsf"+data1);
			var tissueList=data1.split("\n");
			$("#tumorTypeselect").empty();
			var ddl = $("#tumorTypeselect");  
			ddl.append("<option value='2'>Please select tumor type</option>");				
		for (k = 0; k < tissueList.length; k++)
					ddl.append("<option value='" + tissueList[k]+ "'>" + tissueList[k] + "</option>");
					return false;
				
				
	     },
		 error : function(XMLHttpRequest, textStatus, errorThrown) {
					alert("Parse error");
		 }
	});
		
		
}
function save_comment_paragrah(pid,comment){
	alert(pid);
	
	$.ajax({
		//asyn:false,
		type : 'POST',
		url : 'savecomment',
		dataType : 'text',
		data: {
			cancer:"tumor",
            gene:"gene",
            mutation:"mutation",
			pid:pid,
			comment:comment,
			uid:"test"
		},
		success : function(data1){
		    alert(data1);
			return false;
		},
		error : function(XMLHttpRequest, textStatus, errorThrown) {
		    alert("Parse error");
			return false;
		}
	});
	
}
function modifycomment(e,id,index,status){
	   e.preventDefault();
		
		if(status==0){
		    $(id).closest('p').find('textarea').show();
			return;
		}else if(status==1){//save the narrative to the database.
			$(id).closest('p').find('textarea').hide();
			var comment=$(id).closest('p').find('textarea').val();
			$(id).closest('p').find('textarea').empty();
			save_comment_paragrah(index,comment);
			return;
		}
		
	}
	var curdiv="#nardiv";
	function adminmodify(e,cancertype,gene,mutation){
		
		var text="";
		var html="";
		var clone=curdivclone.clone();
		
		clone.find( "p" ).each(function( index ) {
			 index=index+1;
            var cindex="paragraph "+index+":\r\n";
			text=text+cindex+$(this).text()+"\r\n"+"\r\n";
			  
        });
		
		$(curdiv).find( "p" ).each(function( index ) {
		   index=index+1;
           html=html+"paragraph "+index+":<span class=\"notin\" style=\"color:red\">"+ $(this).find('textarea').val()+"</span><br><hr>";
			  
        });
		
		var text1="<textarea rows=20>"+text+"</textarea>";
		$("#adminModify").html(text1+"<div style=\"border-style: dotted;border-width: 2px;\">"+html+"</div>");
		$(curdiv).html(curdivclone.html());
		$(curdiv).hide();
		
		
		
	}
	function modifyparagraph(e,cancertype,gene,mutation){
		curdivclone=$(curdiv).clone();
		$(curdiv).find( "p" ).each(function( index ) {
              //alert( index + ": " +  );
			  index=index+1;
			 
			  var divarea="<div class=\"divcomment\" >sdafasdfsadf</div>";
			  var textarea="<textarea  style=\"display:none;\"></textarea>";
			  var mbutton="<button class=\"notin\" onclick=\"modifycomment(event,this,"+index+",0)\">comment</button>";
			  var sbutton="<button class=\"notin\" onclick=\"modifycomment(event,this,"+index+",1)\">save</button>";
			  var cindex="<span class=\"notin\" style=\"color:blue\">"+index+":</span>";
			  $( this ).html(cindex+" "+divarea+$( this ).html()+mbutton+sbutton+"  <br>"+textarea);
        });
		updateMsg();
		
		
		
	}
	/* function addMessages(xml) {
		  
            if($("status",xml).text() == "2") return;
            timestamp = $("time",xml).text();      
            $("message",xml).each(function(id) {
                message = $("message",xml).get(id);
                $("#messagewindow").prepend("<b>"+$("author",message).text()+
                                            "</b>: "+$("text",message).text()+
                                            "<br />");
            });
        }*/
	 function getmessage(pid,id){
		$.ajax({
		//asyn:false,
		type : 'POST',
		url : 'getcomment',
		dataType : 'text',
		data: {
			cancer:"tumor",
            gene:"gene",
            mutation:"mutation",
			pid:pid,
			
		},
		success : function(data1){
			id.html(data1);
		    //alert(data1);
			return false;
		},
		error : function(XMLHttpRequest, textStatus, errorThrown) {
		    alert("Parse error");
			return false;
		}
	});
		  
		  
	  }
	  function addMessage(){
		  $(curdiv).find( "p" ).each(function( index ) {
              //alert( index + ": " +  );
			  index=index+1;
			 
			  
			 id= $( this ).find('.divcomment');
			  getmessage(index,id);
        });
		
		  
	  }
      function updateMsg() {
		   //alert("hahaer");
             //   alert(timestamp);
           /* $.post("backend.php",{ time: timestamp }, function(xml) {
                $("#loading").remove();            //??load
                addMessages(xml);                  //???????????
            });*/
			addMessage();
			
           setTimeout('updateMsg()', 400);      //?????????,???4s????,???????????
    }	
	
	function adminmodify(e,cancertype,gene,mutation){
		//modifyparagraph
		
		var text="";
		var html="";
		var clone=curdivclone.clone();
		
		clone.find( "p" ).each(function( index ) {
			 index=index+1;
            var cindex="paragraph "+index+":\r\n";
			text=text+cindex+$(this).text()+"\r\n"+"\r\n";
			  
        });
		
		$(curdiv).find( "p" ).each(function( index ) {
			 index=index+1;
           html=html+"paragraph "+index+":<span class=\"notin\" style=\"color:red\">"+ $(this).find('.divcomment').html()+"</span><br><hr>";
			  
        });
		
		var text1="<textarea rows=20>"+text+"</textarea>";
		$("#adminModify").html(text1+"<div style=\"border-style: dotted;border-width: 2px;\">"+html+"</div>");
		$(curdiv).html(curdivclone.html());
		$(curdiv).hide();
		
		
		
	}
	//<button class="searchbutton"  onclick="adminSave(event,'ll','33','44');">Save</button>
//<button class="searchbutton"  onclick="adminNewVersion(event,'ll','33','44');">New Version</button>
  function adminSave(e,cancertype,gene,mutation){
		
		//getnarrativeList();
		loadnarrativeTable();
		
		
	}
	
	 function getnarrativeList(){
		$.ajax({
		//asyn:false,
		type : 'POST',
		url : 'getnarrativeList',
		dataType : 'json',
		data: {
			cancer:"tumor",
            gene:"gene",
            mutation:"mutation"
			
		},
		success : function(data1){
			
		    //alert(data1.aaData);
			return false;
		},
		error : function(XMLHttpRequest, textStatus, errorThrown) {
		    alert("Parse error");
			return false;
		}
	});
		  
		  
	  }
	  
	  function loadnarrativeTable(){
	    var newUrl = "getnarrativeList";
		var n=0;
		if ($.fn.DataTable.isDataTable("#narrativelist")){
			$("#narrativelist").dataTable().fnDestroy();
			
			n=1;
		}
		var string1="{\"sEcho\":0,\"iTotalRecords\":\"1\",\"iTotalDisplayRecords\":\"1\",\"aaData\":[[\"a\",\"b\",\"c\"]]}";
		//var data1=jQuery.parseJSON(string1);
		 var table= $('#narrativelist').dataTable({
					"bProcessing": true,
					"bServerSide": true,
					 "bFilter": true,
					 "iDisplayLength": 25,
					 "bLengthChange": true,
					 // "data": response.data,
					 "sAjaxSource": newUrl,
					 "fnDrawCallback": function( oSettings ) {
						//addeditButton();
						 
					}
		});
		table.fnSort( [ [2,'desc'] ] );
		if(n==1)
		 table.fnDraw();
	   return false;
		//table.columns.adjust().draw();
		
		
		
		
	}
</script>